from antlr4 import *
from jsbachLexer import jsbachLexer
from jsbachParser import jsbachParser
from jsbachTreeVisitor import JSBachTreeVisitor
from jsbachTreeVisitor import JSBachError
import sys
import os

programa = sys.argv[1]
if programa[-4:] != ".jsb":
    raise Exception(f"El programa \"{programa}\" no té l'extensió correcta per JSBach \".jsb\".")

input_stream = FileStream(programa, encoding='utf-8')
print(f"Executant programa \"{programa}\"\n")

lexer = jsbachLexer(input_stream)
token_stream = CommonTokenStream(lexer)

parser = jsbachParser(token_stream)
tree = parser.root()

if len(sys.argv) == 3:
    visitor = JSBachTreeVisitor(sys.argv[2])
elif len(sys.argv) > 3:
    visitor = JSBachTreeVisitor(
        sys.argv[2], [int(param) for param in sys.argv[3:]])
else:
    visitor = JSBachTreeVisitor()

try:
    visitor.visit(tree)
    partitura = ' '.join(JSBachTreeVisitor.partitura)
    if len(partitura) == 0:
        print(f"El programa \"{programa}\" no ha generat una partitura vàlida (no buida).")
    else:
        nom_arxiu = programa[:-4]
        
        f = open(f"{nom_arxiu}.lily", "w")
        f.write('\\version "2.20.0"\n')
        f.write('\\score {\n')
        f.write('\t\\absolute {\n')
        f.write('\t\t\\tempo 4 = 120\n')
        f.write(f'\t\t{partitura}\n')
        f.write('\t}\n')
        f.write('\t\\layout { }\n')
        f.write('\t\\midi { }\n')
        f.write('}\n')
        f.close()

        os.system(f"lilypond {nom_arxiu}.lily")
        os.system(f"timidity -Ow -o {nom_arxiu}.wav {nom_arxiu}.midi")
        os.system(f"ffmpeg -i {nom_arxiu}.wav -codec:a libmp3lame -qscale:a 2 {nom_arxiu}.mp3")
        os.system(f"ffplay {nom_arxiu}.mp3")
        
except JSBachError as e:
    print(e.message)
